// Setting some variables
var isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
var windowHeight = jQuery(window).height();
var windowWidth = jQuery(window).width();
var windowOffsetHeight = windowHeight - 1;

jQuery(document).ready(function() {
	
	/* Full-Width
	-------------------------*/
	var fullWidthSpace = ( windowWidth - jQuery('.full-width').width() ) / 2;
	jQuery('.full-width').css({'width': windowWidth+'px', 'margin-left' : -fullWidthSpace+'px'});
	
	/* Bootstrap Plugins
	-------------------------*/	
	jQuery('a, img, .tt-tooltip').tooltip();
	jQuery('.popup').popover({
		html: 			true,
		placement: 	'top',
		trigger: 		'hover'
	});
	
	/* Purchase Button
	-------------------------*/
	jQuery('.btn-purchase').click(function() {
		jQuery('.theme-detail-page-body').find('.nav-tabs li').removeClass('active');
		jQuery('.theme-detail-page-body').find('.tab-content li').removeClass('active');
		jQuery('.theme-detail-page-body').find('.tab-purchase').addClass('active');
	});
	
	/* Smooth Scroll
	-------------------------*/
	
	/* Conflicts with .nav-tabs anchor links
	jQuery('a[href^="#"]').not('.btn-purchase').on('click', function(e) {
    e.preventDefault();
    jQuery('html,body').animate({scrollTop: jQuery(this.hash).offset().top}, 800);
	});
	*/
	
	jQuery('.btn-purchase, a[href="#purchase"]').on('click', function(e) {
		var offsetTotal = jQuery(this.hash).offset().top;
		var offsetPurchase = offsetTotal - 100;
    e.preventDefault();    
    jQuery('html,body').animate({scrollTop: offsetPurchase}, 800);
	});
	
	// Accordion Toggle
	jQuery('.accordion-toggle').click(function() {
		jQuery(this).find('i').toggleClass('fa-plus-square fa-minus-square');
	});
	
	/* EDD - Easy Digital Downloads
	-------------------------*/	
	jQuery('body').find('.edd_success').addClass('alert alert-success'); 
	
	
	/* FitVids
	https://github.com/davatron5000/FitVids.js/
	-------------------------*/
	jQuery('.video-container').fitVids();    
	jQuery('.video-container').fitVids({ customSelector: "iframe[src^='//fast.wistia.net']"}); 
	//jQuery('.fluid-width-video-wrapper').css('padding-top','56.25%'); // Always display videos 16:9 (100/16*9=56.25)
	
}); 


jQuery(window).load(function() {
	
	/* Slider
	-------------------------*/	
	jQuery('#theme-preview-slider').bxSlider({
		mode: 					'fade',
		auto: 					true,
		autoStart: 			true,
		autoDelay: 			2000,
		pause: 					8000,
		speed: 					1000,
		adaptiveHeight: true,
		controls: 			false,
		pager: 					true,
		prevText: 			'<i class="fa fa-angle-left"></i>',
	  nextText: 			'<i class="fa fa-angle-right"></i>'
	});
	
	// Slideshow "fade"
	jQuery('.slideshow-fade').bxSlider({
		mode: 						'fade',
		infiniteLoop: 		false,
		hideControlOnEnd: true,
		adaptiveHeight: 	true,
		controls: 				true,
		pager: 						false,
		//oneToOneTouch: 		false,
		prevText: 				'<i class="fa fa-angle-left"></i>',
	  nextText: 				'<i class="fa fa-angle-right"></i>'
	});
	
	// Slideshow Testimonials
	jQuery('.slideshow-testimonials').bxSlider({
		auto: 					true,
		mode: 					'fade',
		adaptiveHeight: true,
		controls: 			true,
		pager: 					false,
		prevText: 				'<i class="fa fa-angle-left"></i>',
	  nextText: 				'<i class="fa fa-angle-right"></i>'
	});
	
	/* EDD - Easy Digital Downloads
	-------------------------*/	
	
	function checkoutChanges() {
		setTimeout(function() {
			
			// Extension: VAT Support
			jQuery('#vat_reset, #vat_validate').addClass('btn btn-primary btn-xs');
			
			// VAT Error
			jQuery('.vat-box-error').addClass('alert alert-warning alert-dismissable');
			jQuery('.vat-box-error #text').before('<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>');
			
			// VAT Info
			jQuery('.vat-box-info').addClass('alert alert-info alert-dismissable');
			jQuery('.vat-box-info #text').before('<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>');
						
		}, 1000);
	}
	
	checkoutChanges();
	
	// Update customized elements when changing the payment method
	jQuery('#edd_payment_mode_select :radio').change(function() {
		checkoutChanges();
	});
  
});