<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<p><?php _e( 'No posts found.', 'tt' ); ?></p>
</article>