Theme Author: http://smthemes.com
Theme Homepage: http://smthemes.com/brick/
Buy theme: http://smthemes.com/buy/brick/
Support Forums: http://smthemes.com/support/forum/brick-free-wordpress-theme/